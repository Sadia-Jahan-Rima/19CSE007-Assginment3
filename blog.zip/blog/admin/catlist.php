﻿<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Category List</h2>
				<?php 
				if(isset($_GET['delId'])){
						
				$id1=$_GET['delId'];
				$sql1="DELETE FROM category WHERE id='$id1'";
				$result1= $database->delete($sql1);
				if($result1){
					echo "<span class='sucess'>deleted successfully!</span>";
                    
				}
			else{
				echo "<span class='error'>Not deleted!</span>";
			} }
				?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial NO.</th>
							<th>Category Name</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					<?php 
			
			$sql="SELECT * from category";
			
			$result=$database->select($sql);
			if($result){
				$i=0;
				while($row=mysqli_fetch_assoc($result)){
				$i=$i+1;
				?>
						<tr class="odd gradeX">
							<td><?php echo $i;?></td>
							<td><?php echo $row['name'];?></td>
							<td><a href="editCat.php?catId=<?php echo $row['id']?>">Edit</a> || <a onclick="return confirm('Are you sure want to delete?')"; href= "?delId=<?php echo $row['id']?>">Delete</a></td>
						</tr>
						<?php }} ?>
					</tbody>
					
				</table>
               </div>
            </div>
        </div>
        <script type="text/javascript">

$(document).ready(function () {
    setupLeftMenu();

    $('.datatable').dataTable();
    setSidebarHeight();


});
</script>
<?php include "inc/footer.php";  ?>