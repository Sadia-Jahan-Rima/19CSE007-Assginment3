<?php include "inc/header.php";
include "inc/sidebar.php";
?>
    
        <div class="grid_10">
        
		
            <div class="box round first grid">
                <h2>Update Site Title and Description</h2>
                <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $title=$format->validation($_POST['title']);
                    $slogan=$format->validation($_POST['slogan']);
                    $title = mysqli_real_escape_string($database->link, $title);
                    $slogan = mysqli_real_escape_string($database->link, $slogan);
                    $file_name=$_POST['img'];
                    if(empty($title)||empty($slogan)){
                        echo "<span class='error'>Field must not be empty!</span>";}else{

                        if(!empty($file_name)){
                        $sql1="UPDATE logo set
                         title='$title',
                         slogan='$slogan',
                         img ='$file_name'
                         WHERE id='1'";
                        $result1=$database->select($sql1);}
                        else{
                            
                            $sql1="UPDATE logo set 
                             title='$title',
                             slogan='$slogan'
                             WHERE id='1'";
                            $result1=$database->select($sql1);    
                        }
                        if($result1){
                            echo "<span class='sucess'>updated successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not updated!</span>";
                    }
                    } 
                }
                ?>
                <div class="block sloginblock">  <?php
                $sql="SELECT * From logo where id='1'";
                $result=$database->select($sql);
                if($result){
                    while($row=mysqli_fetch_assoc($result)){
                    ?>         
                 <form action='' method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <label>Website Title</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $row['title'];?>"  name="title" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>Website Slogan</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $row['slogan'];?>" name="slogan" class="medium" />
                            </td>
                        </tr>
						 
                        <tr>
                            <td>
                                <label>Upload Logo</label>
                            </td>
                            <td>
                            <img src="images/<?php echo $row['img'];?>" alt='image' height='50px' width='50px'>
                            <input type="file" name='img'/>
                                
                            </td>
                        </tr>
						 <tr>
                            <td>
                            </td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                        <?php } } ?>
                    </table>
                    </form>
                    
                </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <?php include "inc/footer.php";  ?>                                                             