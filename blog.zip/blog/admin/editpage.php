<?php include "inc/header.php";
include "inc/sidebar.php";

?>
<style>
.delete{
    margin-left:10px;
}
.delete a{
    background-color:#f0f0f0;
    border: 1px solid #ddd;
    color:#444;
    cursor:pointer;
    font-size:20px;
    padding: 4px 10px;
    font-weight: normal;
}
</style>

              
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Page</h2>
                <?php 
				
				if(isset($_GET['delId'])){
						
				$id1=$_GET['delId'];
				$sql1="DELETE FROM page WHERE id='$id1'";
				$result1= $database->delete($sql1);
				if($result1){
					echo "<span class='sucess'>deleted successfully!</span>";
				}
			else{
				echo "<span class='error'>Not deleted!</span>";
			} }
				?>
              
                <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $title=mysqli_real_escape_string($database->link, $_POST['title']);
                    $content=mysqli_real_escape_string($database->link, $_POST['content']);
                    if(empty($title)||empty($content)){
                        echo "<span class='error'>Field must not be empty!</span>";}else{
                        $id=$_GET['pageid'];
                        $sql="UPDATE page set
                        
                         title='$title',
                         content='$content'
                         WHERE id='$id'";
                        $result=$database->update($sql);
                        if($result){
                            echo "<span class='sucess'>updated successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not updated!</span>";
                    }
                    } 
                }
                ?>
                <div class="block">  
                <?php
                if(isset($_GET['pageid'])){

$id=$_GET['pageid'];
$sql="SELECT * FROM page where id='$id' ";
$result=$database->select($sql);
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
?>             
                 <form action="" method="POST" >
                    <table class="form">
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name='title' value="<?php echo $row['title'];?>" class="medium" />
                            </td>
                        </tr>
                       

                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name='content'><?php echo $row['content'];?> </textarea>
                            </td>
                        </tr>
                     
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                                <span class="delete"><a onclick="return confirm('Are you sure want to delete?')"; href="?delId=<?php echo $row['id'];?>">Delete</a></span>
                            </td>
                        </tr>
                    </table>
                    </form>
                                                <?php } } } ?>
                </div>
            </div>
        </div><?php include "inc/footer.php";  ?>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
