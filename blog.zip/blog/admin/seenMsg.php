<?php include "inc/header.php";
?>
<?php
if(!isset($_GET['seenId']) || ($_GET['seenId'])==NULL){
    header("Location:inbox.php");

}
?>
<?php 
    if($_SERVER['REQUEST_METHOD']=="POST"){
        if(isset($_GET['seenId'])){
            $id=$_GET['seenId'];
            $sql="UPDATE contact set
            status='1'
            WHERE id='$id'";
            $result=$database->update($sql);
            if($result){
                echo "<span class='sucess'>Sent to seen box successfully!</span>";}
            } 
     header("Location:inbox.php"); 
        }?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Seen Message</h2>
			
                <div class="block">        
					<?php 
			$id=$_GET['seenId'];
			$sql="SELECT * from contact where id='$id'";
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
        ?>

         <form action='' method='post'>
            
            <table class="form">					
                <tr>
                <td>
                                <label>Name</label>
                            </td>
                    <td>
                        <input type="text" readonly  value="<?php echo $row['f_name']." ".$row['l_name'];?>" class="medium" />
                    </td>
                </tr>
                <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email" readonly value="<?php echo $row['email'];?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Date</label>
                            </td>
                            <td>
                                <input type="text" readonly  value="<?php echo $format->formatDate($row['date']);?>" class="medium" />
                            </td>
                        </tr>
                <tr><td>
                                <label>Message</label>
                </td>
                            <td>
                                <textarea class="tinymce" readonly  name='content'><?php echo $row['msg'];?> </textarea>
                            </td>
                        </tr>
                        <tr> 
                    <td>
                        <input type="submit" name="submit" Value="Ok" />
                    </td>
                </tr>
                     
            </table>
            </form>
            <?php } } ?>
               </div>
            </div>
    </div>
    <script type="text/javascript">

$(document).ready(function () {
    setupLeftMenu();

    $('.datatable').dataTable();
    setSidebarHeight();


});
</script>
    <?php include "inc/footer.php";  ?>

