<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>User List</h2>
                <?php 
				
				if(isset($_GET['delId'])){
						
				$id1=$_GET['delId'];
				$sql1="DELETE FROM user WHERE id='$id1'";
				$result1= $database->delete($sql1);
				if($result1){
					echo "<span class='sucess'>deleted successfully!</span>";
                    
				}
			else{
				echo "<span class='error'>Not deleted!</span>";
			} }
				?>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
						<th>Serial No.</th>
							<th>Username</th>
                            <th>Name</th>
							<th>Email</th>
							<th>details</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
                    <?php
						$sql="SELECT * FROM user order by id Desc";
			
			$result=$database->select($sql);
			if($result){
                $i=0;
				while($row=mysqli_fetch_assoc($result)){
                    $i++;
				?>
						<tr class="odd gradeX">
						<td><?php echo $i;?></td>
                        <td><?php echo $row['username'];?></td>
							<td><?php echo $row['name'];?></td>
							
							<td><?php echo $row['email'];?></td>
                            
							<td><?php echo $format->read($row['details'], 20);?></td>
							<td><a href="viewUser.php?viewId=<?php echo $row['id'];?>">view</a> <?php if(session::get("userRole")=="0"){?> || <a onclick="return confirm('Are you sure want to delete?')"; href="?delId=<?php echo $row['id'];?>">Delete</a></td><?php } ?>
						</tr>
						
					</tbody>
					<?php } } ?>
				</table>
	
               </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
	<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            $('.datatable').dataTable();
			setSidebarHeight();
        });
    </script>
    <?php include "inc/footer.php";  ?>
