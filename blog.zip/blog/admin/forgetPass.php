<?php
include '../lib/session.php';
session::checklogin();?><?php  
include '../config/config.php';  
include '../lib/database.php';
include '../helpers/format.php';
$database=new database() ;
$format=new format() ;
?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Password Recovery Email</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
		<?php
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			$email=$format->validation($_POST['email']);
			$email=mysqli_real_escape_string($database->link,$email);
			$mailSql="SELECT * FROM user WHERE email='$email'";
            $check=$database->select($mailSql);
            $row=mysqli_fetch_assoc($check);
				if($row>0){
					$id=$row['id'];
                    $username=$row['name'];
                $pass=substr($email,0,3);
                $rand=rand(10000,99999);
                $pass='$pass$rand';
                $password=md5($pass);
                $sql="UPDATE user SET password='$password' WHERE id='$id'";
                $result=$database->update($sql);
                $to="email";
                $from="rima@gmail.com";
                $header ='$From: $from\n';
                $header .='MIME-Version: 1.0'.'\r\n';
                $header .='Content-type: text/html; charset=iso-8859-1'.'\r\n';
                $subject="Your password";
                $message="Your website password is".$pass."Please visit website to login";
                $sendMail= mail($to, $subject, $message, $header);
                if($sendMail){
                    echo "<span style='color:green; font-size:25px';>Please check your email!</span>";
                }else{
                    echo "<span style='color:red; font-size:25px';>Mail not sent!</span>";
                }
                
            } 
            else{
					
                echo "<span style='color:red; font-size:25px';>Email not Exist!</span>";
                
            }

            }    
				
			
		
		?>
        <form action='' method='POST'>
			<h1>Password Recovery Email</h1>
		
			<div>
				<input type="email" placeholder="Enter your email" required="" name="email"/>
			</div>
			<div>
				<input type="submit" value="Send" />
			</div>
		</form>
		
	</section>
</div>
</body>
</html>