<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>View Post</h2>
              
                <div class="block">  
                <?php
$id=$_GET['viewId'];
$sql="SELECT * FROM post where id='$id' ";
$result=$database->select($sql);
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
?>             
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" readonly value="<?php echo $row['title'];?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" readonly>
                                <?php
                            $sql1="SELECT * FROM category";
                            $result1=$database->select($sql1);
                            while($row1=mysqli_fetch_assoc($result1)){
                            if($row['cat'] == $row1['id']){
                            $select="selected";
                         }
      else{
        $select="";
      }
        
  echo "<option {$select} value='{$row1['id']}'>{$row1['name']}</option>";
    } ?></select>
                            </td>
                        </tr>
                   

                        
                        <tr>
                            <td>
                                <label>Image</label>
                            </td>
                            <td>
                            <img src="images/<?php echo $row['img'];?>" alt='image' height='150px' width='250px'>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce" readonly><?php echo $row['content'];?> </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input type="text"  readonly value="<?php echo $row['author'];?>" class="medium" /></td>
                                <td><input type="hidden" name='user_id' value="<?php echo session::get("user_id") ?>" class="medium" /></td>

                        </tr>
                        <tr>
                            <td>
                                <label>Tags</label>
                            </td>
                            <td>
                                <input type="text"  readonly value="<?php echo $row['tags'];?>" class="medium" />
                            </td>
                        </tr>
                     
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Ok" />
                            </td>
                        </tr>
                    </table>
                    </form>
                                                <?php } } ?>
                </div>
            </div>
        </div><?php include "inc/footer.php";  ?>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
