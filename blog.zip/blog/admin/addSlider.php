<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Slider</h2>
                <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $title=mysqli_real_escape_string($database->link, $_POST['title']);
                   
                    $file_name=$_FILES['img']['name'];
                    $image="images/slideshow/".$file_name;

                    if(empty($title)||empty($image)){
                        echo "<span class='error'>Field must not be empty!</span>";
                    }else{
                        $sql="INSERT INTO slider(title,image) values('$title','$image')";
                        $result=$database->select($sql);
                        if($result){
                            echo "<span class='sucess'>Inserted successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not Inserted!</span>";
                    }
                    }
                }
                ?>
                <div class="block">               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">

                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name='title' placeholder="Enter slider Title..." class="medium" />
                            </td>
                        </tr>

                        
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <input type="file" name='img'/>
                            </td>
                        </tr>
                       
                       
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Add" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div><?php include "inc/footer.php";  ?>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
