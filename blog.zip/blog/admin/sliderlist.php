<?php include "inc/header.php";
include "inc/sidebar.php";
?>

        <div class="grid_10">
            <div class="box round first grid">
                <h2>Slider List</h2>
                <?php

if(isset($_GET['dltId'])){
        
$id1=$_GET['dltId'];
$sql1="DELETE FROM slider WHERE id='$id1'";
$result1= $database->delete($sql1);
if($result1){
    echo "<span class='sucess'>deleted successfully!</span>";
    header("Location: http://localhost/blog/admin/sliderlist.php");
}
else{
echo "<span class='error'>Not deleted!</span>";
} }
?>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
						<th>Serial No.</th>
							<th>Title</th>
							<th>Image</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<tr class="odd gradeX"><?php
						$sql="SELECT * FROM slider";
			
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){

				?>
						<td><?php echo $row['id'];?></td>
							<td><?php echo $row['title'];?></td>
							<td><img src="<?php echo $row['image'];?>" alt='image' height='50px' width='150px'></td>
							<td>
							<?php if(session::get("userRole")=="0"){ ?>
							
							<a href="editSlider.php?editId=<?php echo $row['id'];?>">Edit</a> 
							|| <a onclick="return confirm('Are you sure want to delete?')"; href="?dltId=<?php echo $row['id'];?>">Delete</a>
							<?php }?>
						</td>
						</tr>
						
					</tbody>
					<?php } } ?>
				</table>
	
               </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
	<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            $('.datatable').dataTable();
			setSidebarHeight();
        });
    </script>
    <?php include "inc/footer.php";  ?>
