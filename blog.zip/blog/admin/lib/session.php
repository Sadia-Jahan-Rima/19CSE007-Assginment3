<?php 
class session{
    public static function init(){
            session_start();
    }
    public static function set($index,$data){
        $_SESSION[$index]=$data;
    }
    public static function get($index){
        if(isset($_SESSION[$index])){
        return $_SESSION[$index];}
        else{
            return false;       }
    }
    public static function checkSession(){
        self::init();
        if(self::get('login')==false){

        self::destroy();
        header("Location:login.php");}
        }
        public static function checklogin(){
            self::init();
            if(self::get('login')==true){
            header("Location:index.php");}
            }
     public static function destroy(){
        session_destroy();
        header("Location:login.php");
        }
    }


?>