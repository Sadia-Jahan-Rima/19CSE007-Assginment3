<?php include "inc/header.php";
include "inc/sidebar.php";
$userid=session::get("user_id");
$userRole=session::get("userRole");
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update User Profile</h2>
              
                <?php
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $name=mysqli_real_escape_string($database->link, $_POST['name']);
                    $details=mysqli_real_escape_string($database->link, $_POST['details']);
                    $email=mysqli_real_escape_string($database->link, $_POST['email']);
                    ?><?php
                        $sql="UPDATE user set
                        name='$name',
                        email='$email',
                        details='$details'
                        WHERE id='$userid'";
                        $result=$database->update($sql);
                        if($result){
                            echo "<span class='sucess'>Updated successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not Updated!</span>";
                    }}
                ?>
                <div class="block">  
                <?php
$sql="SELECT * FROM user where id='$userid' and role='$userRole'";
$result=$database->select($sql);
$row=mysqli_fetch_assoc($result);
if($row){
?>             
                 <form action="" method="POST">
                    <table class="form">
                    <tr>
                            <td>
                                <label>Username</label>
                            </td>
                            <td>
                                <input type="text" name='username' value="<?php echo $row['username'];?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name='name' value="<?php echo $row['name'];?>" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email" name='email' value="<?php echo $row['email'];?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>details</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name='details'><?php echo $row['details'];?> </textarea>
                            </td>
                        </tr>

                     
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="update" />
                            </td>
                        </tr>
                    </table>
                    </form><?php }  ?>
                                                
                </div>
            </div>
        </div><?php include "inc/footer.php";  ?>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
