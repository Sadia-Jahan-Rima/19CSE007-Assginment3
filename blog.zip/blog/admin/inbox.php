﻿<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Inbox</h2>
				<?php 
				
				if(isset($_GET['delId'])){
						
				$id1=$_GET['delId'];
				$sql1="DELETE FROM contact WHERE id='$id1'";
				$result1= $database->delete($sql1);
				if($result1){
					echo "<span class='sucess'>deleted successfully!</span>";
				}
			else{
				echo "<span class='error'>Not deleted!</span>";
			} }
				?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
					
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					<?php 
			
			$sql="SELECT * from contact where status='0'";
			
			$result=$database->select($sql);
			if($result){
				$i=0;
				while($row=mysqli_fetch_assoc($result)){
					
				$i=$i+1;
				?>
						<tr class="odd gradeX">

							<td><?php echo $i;?></td>
							<td><?php echo $row['f_name']." ".$row['l_name'];?></td>
							<td><?php echo $row['email'];?></td>
							<td><?php echo $format->read($row['msg'],30);?></td>
							<td><?php echo $format->formatDate($row['date']);?></td>
							<td><a href="viewMsg.php?viewId=<?php echo $row['id'];?>">View</a> || 
							<a href="replyMsg.php?replyId=<?php echo $row['id'];?>">reply</a> || 
							<a href="seenMsg.php?seenId=<?php echo $row['id'];?>">seen</a> </td>
							</tr>
							<?php }} ?>				
							</tbody>
							</table>
							
				<table class="data display datatable" id="example">
					<thead>
					
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					<?php 
			
			$sql="SELECT * from contact where status='1'";
			
			$result=$database->select($sql);
			if($result){
				$i=0;
				while($row=mysqli_fetch_assoc($result)){
					
				$i=$i+1;
				?>
						<tr class="odd gradeX">
							<td><?php echo $i;?></td>
							<td><?php echo $row['f_name']." ".$row['l_name'];?></td>
							<td><?php echo $row['email'];?></td>
							<td><?php echo $format->read($row['msg'],30);?></td>
							<td><?php echo $format->formatDate($row['date']);?></td>
							<td>
							<a href="viewMsg.php?viewId=<?php echo $row['id'];?>">View</a> || <a onclick="return confirm('Are you sure want to delete?')"; href="?delId=<?php echo $row['id'];?>">delete</a> </td>
</tr>
<?php }} ?>				
					</tbody>
				</table>
               </div>

            </div>

			
    </div>
    <script type="text/javascript">

$(document).ready(function () {
    setupLeftMenu();

    $('.datatable').dataTable();
    setSidebarHeight();


});
</script>
    <?php include "inc/footer.php";  ?>

