<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New page</h2>
                <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $title=$format->validation($_POST['title']);
                    $content=$format->validation($_POST['content']);
                    $title=mysqli_real_escape_string($database->link, $title);
                    $content=mysqli_real_escape_string($database->link, $content);

                    if(empty($title)||empty($content)){
                        echo "<span class='error'>Field must not be empty!</span>";
                    }else{
                        $sql="INSERT INTO page(title,content) values('$title','$content')";
                        $result=$database->select($sql);
                        if($result){
                            echo "<span class='sucess'>created successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not created!</span>";
                    }
                    }
                }
                ?>
                <div class="block">               
                 <form action="" method="POST">
                    <table class="form">

                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name='title' placeholder="Enter page Title..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name='content'></textarea>
                            </td>
                        </tr>
                        
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div><?php include "inc/footer.php";  ?>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
