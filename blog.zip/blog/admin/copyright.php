﻿<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
		
            <div class="box round first grid">
            
                <h2>Update Copyright Text</h2>
                
                <?php 
               
                if($_SERVER['REQUEST_METHOD']=="POST"){
                   
                    $info=$format->validation($_POST["copyright"]);
                    $info=mysqli_real_escape_string($database->link, $info);
                    if(empty($info)){
                        echo "<span class='error'>Field must not be empty!</span>";}else{
                        $sql1="UPDATE copyright SET
                         info='$info'
                         WHERE id='1'";
                        $result1=$database->update($sql1);}
                        if($result1){
                            echo "<span class='sucess'>Inserted successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not Inserted!</span>";
                    }
                    }
                ?>
                <div class="block copyblock"> 
                 <form action='copyright.php' method="POST">
                 <?php
                $sql="SELECT * From copyright where id='1'";
                $result=$database->select($sql);
                if($result){
                    while($row=mysqli_fetch_assoc($result)){
                    ?>           
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" value="<?php echo $row['info'];?>" name="copyright" class="large" />
                            </td>
                        </tr>
						
						 <tr> 
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                   
                    </form>
                    <?php } } ?>
                </div>
                
            </div>
        </div>
        <?php include "inc/footer.php";  ?>
