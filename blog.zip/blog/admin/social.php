<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Social Media</h2>
                <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    
                    $fb=mysqli_real_escape_string($database->link, $_POST['facebook']);
                    $twitter=mysqli_real_escape_string($database->link, $_POST['twitter']);
                    $ln=mysqli_real_escape_string($database->link, $_POST['linkedin']);
                    $google=mysqli_real_escape_string($database->link, $_POST['googleplus']); 
                    ?><?php
                    if(empty($fb)||empty($twitter)||empty($ln)||empty($google)){
                        echo "<span class='error'>Field must not be empty!</span>";}else{
                        $sql="UPDATE social set
                         fb='$fb',
                         twitter='$twitter',
                         ln='$ln',
                         google='$google'
                         WHERE id='1'";
                        $result=$database->update($sql);}
                        if($result){
                            echo "<span class='sucess'>Inserted successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not Inserted!</span>";
                    }
                    }
                ?>
                <div class="block"> 
                <?php
                $sql="SELECT * From social where id='1'";
                $result=$database->select($sql);
                if($result){
                    while($row=mysqli_fetch_assoc($result)){
                    ?>                       
                 <form action='' method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <label>Facebook</label>
                            </td>
                            <td>
                                <input type="text" name="facebook" value="<?php echo $row['fb'];?>" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>Twitter</label>
                            </td>
                            <td>
                                <input type="text" name="twitter" value="<?php echo $row['twitter'];?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>LinkedIn</label>
                            </td>
                            <td>
                                <input type="text" name="linkedin" value="<?php echo $row['ln'];?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>Google Plus</label>
                            </td>
                            <td>
                                <input type="text" name="googleplus" value="<?php echo $row['google'];?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    
                    </form>
                    <?php } } ?>
                </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <?php include "inc/footer.php";  ?>
