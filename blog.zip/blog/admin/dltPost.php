<?php
include '../lib/session.php';
session::checkSession();?> 
<?php
include '../config/config.php';  
include '../lib/database.php';
include '../helpers/format.php';
$database=new database() ;
$format=new format() ;
?>
<?php

if(isset($_GET['dltId'])){
        
$id1=$_GET['dltId'];
$sql1="DELETE FROM post WHERE id='$id1'";
$result1= $database->delete($sql1);
if($result1){
    echo "<span class='sucess'>deleted successfully!</span>";
    header("Location: http://localhost/blog/admin/postlist.php");
}
else{
echo "<span class='error'>Not deleted!</span>";
} }
?>
