﻿<?php include "inc/header.php";
include "inc/sidebar.php";
?>

        <div class="grid_10">
            <div class="box round first grid">
                <h2>Post List</h2>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
						<th>Serial No.</th>
							<th width='5%'>Cat</th>
							<th width='15%'>Title</th>
							<th width='20%'>Content</th>
							<th>Image</th>
							<th>Author</th>
							<th>Tags</th>
							<th>date</th>
							<th width='15%'>Action</th>
						</tr>
					</thead>
					<tbody>
						<tr class="odd gradeX"><?php
						$sql="SELECT post.*, category.name FROM post inner join category on post.cat=category.id order by id desc";
			
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){

				?>
						<td><?php echo $row['id'];?></td>
							<td><?php echo $row['name'];?></td>
							<td><?php echo $row['title'];?></td>
							<td><?php echo $row['content'];?></td>
							<td><img src="images/<?php echo $row['img'];?>" alt='image' height='50px' width='50px'></td>
							<td><?php echo $row['author'];?></td>
							<td><?php echo $row['tags'];?></td>
							<td><?php echo $row['date'];?></td>
							<td><a href="viewPost.php?viewId=<?php echo $row['id'];?>">view</a>
							<?php if(session::get("user_id") == $row['user_id']||session::get("userRole")=="0"){ ?>
							||
							<a href="editPost.php?editId=<?php echo $row['id'];?>">Edit</a> 
							|| <a onclick="return confirm('Are you sure want to delete?')"; href="dltPost.php?dltId=<?php echo $row['id'];?>">Delete</a>
							<?php }?>
						</td>
						</tr>
						
					</tbody>
					<?php } } ?>
				</table>
	
               </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
	<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            $('.datatable').dataTable();
			setSidebarHeight();
        });
    </script>
    <?php include "inc/footer.php";  ?>
