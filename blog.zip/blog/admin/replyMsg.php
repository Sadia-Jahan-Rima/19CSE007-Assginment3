<?php include "inc/header.php";
include "inc/sidebar.php";
?>
<?php
if(!isset($_GET['replyId']) || ($_GET['replyId'])==NULL){
    header("Location:inbox.php");

}
?>

        <div class="grid_10">
            <div class="box round first grid">
                <h2>Reply Message</h2>
                <?php 
    if($_SERVER['REQUEST_METHOD']=="POST"){
        $to=$format->validation($_POST['to']);
        $from=$format->validation($_POST['from']);
        $subject=$format->validation($_POST['subject']);
        $msg=$format->validation($_POST['content']);
        $send=mail($to, $subject, $msg);
        if($send){
            echo "<span class='sucess'>Email send successfully!</span>";
        }
    else{
        echo "<span class='error'>Something went wrong!</span>";
    }
       
        }?>w
                <div class="block">        
					<?php 
			$id=$_GET['replyId'];
			$sql="SELECT * from contact where id='$id'";
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
        ?>

         <form action='' method='post'>
            
            <table class="form">	
            <tr>
                            <td>
                                <label>To</label>
                            </td>
                            <td>
                                <input type="email" name='to' readonly value="<?php echo $row['email'];?>" class="medium" />
                            </td>
                        </tr>				
                <tr>
                <td>
                                <label>From</label>
                            </td>
                    <td>
                        <input type="email" name="from" placeholder='Enter your email' class="medium" />
                    </td>
                </tr>
                
                        <tr>
                            <td>
                                <label>Subject</label>
                            </td>
                            <td>
                                <input type="text" name="subject" placeholder='subject' class="medium" />
                            </td>
                        </tr>
                <tr><td>
                                <label>Message</label>
                </td>
                            <td>
                                <textarea class="tinymce"  name='content'> </textarea>
                            </td>
                        </tr>
                        <tr> 
                    <td>
                        <input type="submit" name="submit" Value="Send" />
                    </td>
                </tr>
                     
            </table>
            </form>
            <?php } } ?>
               </div>
            </div>
    </div>
    <script type="text/javascript">

$(document).ready(function () {
    setupLeftMenu();

    $('.datatable').dataTable();
    setSidebarHeight();


});
</script>
    <?php include "inc/footer.php";  ?>

