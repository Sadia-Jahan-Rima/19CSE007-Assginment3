<?php include "inc/header.php";
?>
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>view User Profile</h2>
                <?php 
				
				if(isset($_GET['viewId'])){
						
				$id=$_GET['viewId'];
                }
                ?><?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                  header('Location:userList.php');
                    }
                ?>
                <div class="block">  
                <?php
$sql="SELECT * FROM user where id='$id'";
$result=$database->select($sql);
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
?>             
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                    <tr>
                            <td>
                                <label>Username</label>
                            </td>
                            <td>
                                <input type="text" name='username' readonly value="<?php echo $row['username'];?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name='name' readonly value="<?php echo $row['name'];?>" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="email" name='email' readonly value="<?php echo $row['email'];?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>details</label>
                            </td>
                            <td>
                                <textarea class="tinymce" readonly name='details'><?php echo $row['details'];?> </textarea>
                            </td>
                        </tr>

                     
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Ok" />
                            </td>
                        </tr>
                    </table>
                    </form>
                                                <?php } } ?>
                </div>
            </div>
        </div><?php include "inc/footer.php";  ?>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
