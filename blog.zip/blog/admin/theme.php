<?php include "inc/header.php";
include "inc/sidebar.php";
?>

        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update theme</h2>
               <div class="block copyblock">
               <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $theme=mysqli_real_escape_string($database->link, $_POST['theme']);
                    if(empty($theme)){
                        echo "<span class='error'>Field must be filled!</span>";
                    }else{
                        $sql="UPDATE theme SET name='$theme' WHERE id='1'";
                        $result=$database->update($sql);
                        if($result){
                            echo "<span class='sucess'>Updated successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not Updated!</span>";
                    }
                    }
                }
                ?> 
                <?php 
                
                        $sql="SELECT * FROM theme where id='1'";
                        $result=$database->select($sql);
                        $row=mysqli_fetch_assoc($result);
                        if($row){
                ?>

                 <form action='' method='post'>
                    
                    <table class="form">					
                        <tr>
                            <td>
                                <input <?php if($row['name']=="default"){ echo "checked"; } ?> type="radio" name="theme" value="default" class="medium">Default
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input <?php if($row['name']=="green"){ echo "checked"; } ?> type="radio" name="theme" value="green" class="medium">Green
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="radio" <?php if($row['name']=="blue"){ echo "checked"; } ?> name="theme" value="blue" class="medium">blue
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Change" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } ?>
                </div>
            </div>
        </div>
        <?php include "inc/footer.php";  