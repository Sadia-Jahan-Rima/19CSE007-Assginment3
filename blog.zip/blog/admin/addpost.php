<?php include "inc/header.php";
include "inc/sidebar.php";
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Post</h2>
                <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $title=mysqli_real_escape_string($database->link, $_POST['title']);
                    $cat=mysqli_real_escape_string($database->link, $_POST['cat']);
                    $content=mysqli_real_escape_string($database->link, $_POST['content']);
                    $author=mysqli_real_escape_string($database->link, $_POST['author']);
                    $tags=mysqli_real_escape_string($database->link, $_POST['tags']);
                    $user_id=mysqli_real_escape_string($database->link, $_POST['user_id']);
                    //$permit=array('jpg','jpeg','png','gif');
                    $file_name=$_FILES['img']['name'];
                    //$file_size=$_FILES['img']['size'];
                    //$file_temp=$_FILES['img']['tmp_name'];
                    //$div=explode('.',$file_name);
                    //$file_ext=strtolower(end($div));
                    //$unique_img=substr((time()),0,10).".".$file_ext;
                   // $unique_img="../images/".$unique_img;

                    if(empty($title)||empty($cat)||empty($file_name)||empty($author)||empty($tags)||empty($content)){
                        echo "<span class='error'>Field must not be empty!</span>";
                    }else{
                        $sql="INSERT INTO post(cat,title,content,img,author,tags,user_id) values('$cat','$title','$content','$file_name','$author','$tags','$user_id')";
                        $result=$database->select($sql);
                        if($result){
                            echo "<span class='sucess'>Inserted successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not Inserted!</span>";
                    }
                    }
                }
                ?>
                <div class="block">               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">

                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name='title' placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="cat">
                                    <?php
                                            $sql="SELECT * FROM category";
                                            $result=$database->select($sql);
                                            if($result){
                                                while($row=mysqli_fetch_assoc($result)){
                                    ?>
                                    <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                                <?php } } ?>
                                </select>
                            </td>
                        </tr>
                   

                        
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <input type="file" name='img'/>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name='content'></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input type="text" name='author' value="<?php echo session::get("username") ?>" class="medium" />
                                <input type="hidden" name='user_id' value="<?php echo session::get("user_id") ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Tags</label>
                            </td>
                            <td>
                                <input type="text" name='tags' placeholder="Enter Post Tags..." class="medium" />
                            </td>
                        </tr>
                     
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div><?php include "inc/footer.php";  ?>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
