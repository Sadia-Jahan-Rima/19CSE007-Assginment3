<?php 
				
				if(isset($_GET['delId'])){
						
				$id1=$_GET['delId'];
				$sql1="DELETE FROM category WHERE id='$id1'";
				$result1= $database->delete($sql1);
				if($result1){
					echo "<span class='sucess'>deleted successfully!</span>";
                    header("Location:catlist.php");
				}
			else{
				echo "<span class='error'>Not deleted!</span>";
			} }
				?>