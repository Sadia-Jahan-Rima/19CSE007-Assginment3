<?php include "inc/header.php";
include "inc/sidebar.php";
?>
  <?php
                if(!isset($_GET['editId']) || ($_GET['editId'])==NULL){
                    header("Location:sliderlist.php");
                
                }
                else{
                    $id=$_GET['editId'];
                }
                ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Slider</h2>
              
                <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $title=mysqli_real_escape_string($database->link, $_POST['title']);
                    $file_name=$_FILES['img']['name'];
                    $image="images/slideshow/".$file_name;
                    ?><?php
                    if(empty($title)){
                        echo "<span class='error'>Field must not be empty!</span>";}else{

                        if(!empty($file_name)){
                        $id=$_GET['editId'];
                        $sql="UPDATE slider set
                         title='$title',
                         image='$image'
                        WHERE id='$id'";
                        $result=$database->update($sql);}
                        else{
                            $id=$_GET['editId'];
                            $sql="UPDATE slider set
                             title='$title' WHERE id='$id'";
                            $result=$database->update($sql);    
                        }
                        if($result){
                            echo "<span class='sucess'>Updated successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not updated!</span>";
                    }
                    } 
                }
                ?>
                <div class="block">  
                <?php

$id=$_GET['editId'];
$sql="SELECT * FROM slider where id='$id' ";
$result=$database->select($sql);
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
?>             
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name='title' value="<?php echo $row['title'];?>" class="medium" />
                            </td>
                        </tr>
                       
                   

                        
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                            <img src="<?php echo $row['image'];?>" alt='image' height='50px' width='50px'>
                                <input type="file" name='img'/>
                            </td>
                        </tr>
                        
                       
                     
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                                                <?php } } ?>
                </div>
            </div>
        </div><?php include "inc/footer.php";  ?>
        <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
