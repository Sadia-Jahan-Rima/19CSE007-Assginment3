<?php include "inc/header.php";
?>
<?php if( !session::get("userRole")=="0")
header("Location:index.php");
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New user</h2>
               <div class="block copyblock"> 
                <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $username=$format->validation($_POST['username']);
                    $password=$format->validation(MD5($_POST['password']));
                    $email=$format->validation($_POST['email']);
					$role=$format->validation($_POST['role']);
                    $username=mysqli_real_escape_string($database->link,$username);
                    $password=mysqli_real_escape_string($database->link,$password);
                    $role=mysqli_real_escape_string($database->link, $role);
                    $email=mysqli_real_escape_string($database->link,$email);
                    if(empty($username)||empty($password)||empty($email)){
                        echo "<span class='error'>Field must be filled!</span>";

                    }else{
                    $mailSql="SELECT * FROM user WHERE email='$email'";

                    $check=$database->select($mailSql);
                    $row=mysqli_fetch_assoc($check);
                    
                    if($row){
                        echo "<span class='error'>email is already exist!</span>";

                    }

                    else{
                        $sql="INSERT INTO user(username,password,email,role) values('$username','$password','$email','$role')";
                        $result=$database->select($sql);
                        if($result){
                            echo "<span class='success'>created successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Not created!</span>";
                    }
                    }
                }
                }
                ?>
                 <form action='' method='post'>
                    
                    <table class="form">					
                        <tr>
                            <td>Username</td>
                            <td>
                                <input type="text" name="username" placeholder="Enter username..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td>
                                <input type="text" name="password" placeholder="Enter password..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>
                                <input type="email" name="email" placeholder="Enter email..." class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td>Role</td>
                            <td>
                                <select id='select' name="role">
                                <option>Select user</option>
                                <option value="0">Admin</option>
                                <option value="1">Auther</option>
                                <option value="2">editor</option></select>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Create" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
        <?php include "inc/footer.php";  ?>