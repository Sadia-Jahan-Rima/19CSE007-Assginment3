<div class="slidersection templete clear">
        <div id="slider"><?php
        $sql="SELECT * FROM social";
			
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
				?>
            <a href="<?php echo $row['fb'];?>"><img src="images/slideshow/01.jpg" height='280px' width='960px' alt="nature 1" height="260px" title="Web designing" /></a>
            <a href="<?php echo $row['twitter'];?>"><img src="images/slideshow/02.jpg" alt="nature 2" title="HTML" /></a>
            <a href="<?php echo $row['ln'];?>"><img src="images/slideshow/03.jpg" alt="nature 3" title="CSS" /></a>
            <a href="<?php echo $row['google'];?>"><img src="images/slideshow/04.jpg" alt="nature 4" title="PHP" /></a>
        </div><?php } } ?>

</div>