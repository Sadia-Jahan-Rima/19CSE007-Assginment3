<div class="footersection templete clear">
	  <div class="footermenu clear">
		<ul>
			<li><a href="#">Home</a></li>
			<li><a href="#">About</a></li>
			<li><a href="#">Contact</a></li>
			<li><a href="#">Privacy</a></li>
		</ul>
	  </div>
	  <?php
        $sql="SELECT * FROM copyright";
			
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
				?>
	  <p>&copy; <?php echo $row['info'];?>.</p> <?php } } ?>
	</div>
	<div class="fixedicon clear">
	<?php
        $sql="SELECT * FROM social";
			
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
				?>
		<a href="<?php echo $row['fb'];?>"><img src="images/fb.png" alt="Facebook"/></a>
		<a href="<?php echo $row['twitter'];?>"><img src="images/tw.png" alt="Twitter"/></a>
		<a href="<?php echo $row['ln'];?>"><img src="images/in.png" alt="LinkedIn"/></a>
		<a href="<?php echo $row['google'];?>"><img src="images/gl.png" alt="GooglePlus"/></a>
		<?php } } ?>
	</div>
		
	<script type="text/javascript" src="js/scrolltop.js"></script>
</body>
</html>