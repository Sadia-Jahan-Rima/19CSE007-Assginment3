<div class="sidebar clear">
			<div class="samesidebar clear">
				<h2>Categories</h2>
					<ul>
					<?php
				$sql="SELECT * from  category";
				$result=$database->select($sql);
				if($result){
					while($row=mysqli_fetch_assoc($result)){?>
						<li><a href='post.php?id=<?php echo $row['id']; ?>'> <?php echo $row['name']; ?> </a></li>
						<?php }} else{
							header('Location:404.php');
						}
						
						?>						
					</ul>
			</div>
			
			<div class="samesidebar clear">
				<h2>Latest articles</h2>
				<?php 
				$sql="SELECT * from  post limit 4";
				$result=$database->select($sql);
				if($result){
					while($row=mysqli_fetch_assoc($result)){?>
					<div class="popular clear">
					<h3><?php echo $row['title']; ?></h3>
					<a href='post.php?id=<?php echo $row['id']; ?>'>
					<img src="images/<?php echo $row['img']; ?>" alt="post image"/></a>
				<p>
				<a href='post.php?id=<?php echo $row['id']; ?>' style="text-decoration:none">
				<?php echo $format->read($row['content'],100); ?></a>
				</p>	
					</div>
					<?php }}else{
						header('Location:404.php');
					} ?>
	
			</div>
			
		</div>
	</div>