 <?php
include 'config/config.php';  
include 'lib/database.php';
include 'helpers/format.php';
$database=new database() ;
$format=new format() ;
?>
<!DOCTYPE html>
<html>
<head>
<?php 
include 'scripts/meta.php';
include 'scripts/javascript.php'; 
	
	include 'scripts/css.php';?>	
</head>
<body>
	<div class="headersection templete clear">
		<a href="#">
			<div class="logo">
			<?php
			$sql="SELECT * FROM logo";
			
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
				?>
				<img src="images/<?php echo $row['img'];?>" alt="Logo"/>
				<h2><?php echo $row['title'];?></h2>
				<p><?php echo $row['slogan'];?></p>
			</div><?php } } ?>
		</a>
		<div class="social clear">
			<div class="icon clear"><?php
			$sql="SELECT * FROM social";
			
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
				?>
				<a href="<?php echo $row['fb'];?>" target="_blank"><i class="fa fa-facebook"></i></a>
				<a href="<?php echo $row['twitter'];?>" target="_blank"><i class="fa fa-twitter"></i></a>
				<a href="<?php echo $row['ln'];?>" target="_blank"><i class="fa fa-linkedin"></i></a>
				<a href="<?php echo $row['google'];?>" target="_blank"><i class="fa fa-google-plus"></i></a>
			</div>
			<div class="searchbtn clear">
			<form action="search.php" method="POST">
				<input type="text" name="search" placeholder="Search keyword..."/>
				<input type="submit" name="submit" value="Search"/>
				
			</form>
			<?php } } ?>
			</div>
		</div>
	</div>
<div class="navsection templete">
	<ul><?php
	$path=$_SERVER['SCRIPT_FILENAME'];
      $page=basename($path,'.php');?>
		<li><a <?php if($page=="index")
								echo 'id="active"';?> href="index.php">Home</a></li><?php
                                            $sql="SELECT * FROM page";
                                            $result=$database->select($sql);
                                            if($result){
                                                while($row=mysqli_fetch_assoc($result)){
                                    ?>
                                <li><a 
								<?php if(isset($_GET['pageid']) && $_GET['pageid']==$row['id'] )
								echo 'id="active"';?>
								href="page.php?pageid=<?php echo $row['id']; ?>"><?php echo $row['title']; ?></a> </li><?php } } ?>
		<li><a <?php if($page=="contact")
								echo 'id="active"';?> href="contact.php">Contact</a></li>
	</ul>
</div>
<?php include 'inc/slider.php';