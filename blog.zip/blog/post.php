<?php 
include 'inc/header.php'; 
if(!isset($_GET['id']) || isset($_GET['id'])==NULL){
	header('Location:404.php');
}
else{
	$id=$_GET['id'];
}
?>	
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<div class="about">
				<?php
				$sql="SELECT * from  post where id=$id";
				$result=$database->select($sql);
				if($result){
					while($row=mysqli_fetch_assoc($result)){?>
				<h2><?php echo $row['title']; ?></h2>
				<h4><?php echo $format->formatDate($row['date']); ?>, By <?php echo $row['author']; ?></h4>
				<img src="<?php echo 'images/'.$row['img']; ?>" alt="post image"/>
				
				<p>
				<?php echo $row['content']; ?>
				</p>

				<div class="relatedpost clear">
				<h2>Related articles</h2>
				<?php
				$cat_id=$row['cat'];
				$sql1="SELECT * from  post where cat=$cat_id limit 6";
				$result1=$database->select($sql1);
				if($result1){
					while($row1=mysqli_fetch_assoc($result1)){?>

<a href='post.php?id=<?php echo $row['id']; ?>'> <img src="<?php echo 'images/'.$row['img']; ?>" alt="post image"/> </a>
<?php }} else{
			echo 'No related post available';
		}?>			
</div>
		
<?php }} else{
			header('Location:404.php');
		}?>		
	</div>
	
		
		</div>

		<?php include 'inc/sidebar.php'; ?>	
		<?php include 'inc/footer.php'; ?>	
