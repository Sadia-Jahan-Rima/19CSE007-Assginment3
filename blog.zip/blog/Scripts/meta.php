
<meta name="language" content="English">
<meta name="description" content="It is a website about education">
<meta name="keywords" content="blog,cms blog">
<?php
                if(isset($_GET['pageid'])){
                    $id=$_GET['pageid'];
	$sql="SELECT * FROM page where id=$id";
			
	$result=$database->select($sql);
	if($result){
		while($row=mysqli_fetch_assoc($result)){
		?>
	
	<title><?php echo $row['title'] ;?> - <?php echo title; ?></title><?php } } } 
	elseif(isset($_GET['id'])){
		
			$id=$_GET['id'];
$sql="SELECT * FROM post where id=$id";
	
$result=$database->select($sql);
if($result){
while($row=mysqli_fetch_assoc($result)){
?>

<title><?php echo $row['title'] ;?> - <?php echo title; ?></title>
<?php } } } else{ ?>
	<title><?php echo $format->title(); ?> - <?php echo title; ?> </title>	<?php
	} ?>
    <meta name="author" content="Delowar">