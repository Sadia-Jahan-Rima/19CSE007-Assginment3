<link rel="stylesheet" href="font-awesome-4.5.0/css/font-awesome.css">	
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="style.css">

<style>

</style>
<?php 
                
                $sql="SELECT * FROM theme where id='1'";
                $result=$database->select($sql);
                $row=mysqli_fetch_assoc($result);
                if($row['name']=="default"){
                  echo '<link rel="stylesheet" href="theme/default.css">';
                }
                elseif($row['name']=="green"){
                  echo '<link rel="stylesheet" href="theme/green.css">';
                }
                elseif($row['name']=="blue"){
                  echo '<link rel="stylesheet" href="theme/blue.css">';
                }

        ?>
