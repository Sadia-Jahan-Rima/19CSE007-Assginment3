<?php 
include 'inc/header.php'; 
?>
<?php
	if(!isset($_POST['search']) || isset($_POST['search'])==NULL){
		header('Location:404.php');
	}else{
	$id=$_POST['search'];}
if($_SERVER['REQUEST_METHOD']=="POST"){
?>	
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
        <?php
				$sql="SELECT * from  post where title like '%$id%' or content like '%$id%'";
				$result=$database->select($sql);
				if($result){
					while($row=mysqli_fetch_assoc($result)){?>
        <div class="samepost clear">
			
		
            <h2><a href='post.php?id=<?php echo $row['id']; ?>'> <?php echo $row['title']; ?> </a></h2>
            <h4><?php echo $format->formatDate($row['date']); ?>, By <a href="#"><?php echo $row['author']; ?></a></h4>
             <a href="#"><img src="<?php echo 'images/'.$row['img']; ?>" alt="post image"/></a>
            
            <?php echo $format->read($row['content'],200); ?>
            
            <div class="readmore clear">
                <a href='post.php?id=<?php echo $row['id']; ?>'>Read More</a>
                            </div>
		
		</div>
		<?php }} else{
			echo "<p> Object not found!</p>";
		}}?>
	</div>
	

		<?php include 'inc/sidebar.php'; ?>	
		<?php include 'inc/footer.php'; ?>	
