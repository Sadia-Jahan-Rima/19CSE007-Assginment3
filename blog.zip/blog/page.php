<?php 
include 'inc/header.php'; 
?>
<?php
                if(!isset($_GET['pageid']) || ($_GET['pageid'])==NULL){
                    //header("Location:404.php");
                
                }
                else{
                    $id=$_GET['pageid'];
                }
                ?>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<div class="about"><?php
			$id=$_GET['pageid'];
			$sql="SELECT * FROM page where id='$id' ";
			$result=$database->select($sql);
			if(mysqli_num_rows($result)>0){
				while($row=mysqli_fetch_assoc($result)){
			?>             
				<h2><?php echo $row['title'];?></h2>
	
				<p><?php echo $row['content'];?></p><?php } } ?>

		</div></div>
		<?php include 'inc/sidebar.php'; ?>	
		<?php include 'inc/footer.php'; ?>