<?php 
include 'inc/header.php'; 
?>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<div class="about">
				<h2>Contact us</h2>
					<?php
 if($_SERVER['REQUEST_METHOD']=="POST"){
					$f_name=$format->validation($_POST['firstname']);
					$l_name=$format->validation($_POST['lastname']);
					$msg=$format->validation($_POST['msg']);
					$email=$format->validation($_POST['email']);
                    $f_name=mysqli_real_escape_string($database->link, $f_name);
                    $l_name=mysqli_real_escape_string($database->link,$l_name);
                    $msg=mysqli_real_escape_string($database->link, $msg);
                    $email=mysqli_real_escape_string($database->link, $email);
                   
                

                    if(empty($f_name)||empty($l_name)||empty($msg)||empty($email)){
                        echo "<span class='error'>Field must not be empty!</span>";
                    }else{
                        $sql="INSERT INTO contact(f_name,l_name,email,msg) values('$f_name','$l_name','$email','$msg')";
                        $result=$database->insert($sql);
                        if($result){
                            echo "<span class='sucess'>message send successfully!</span>";
                        }
                    else{
                        echo "<span class='error'>Nessage Not Inserted!</span>";
                    }
                    }
                }?>
			<form action="" method="post">
				<table>
				<tr>
					<td>Your First Name:</td>
					<td>
					<input type="text" name="firstname" placeholder="Enter first name" required="1"/>
					</td>
				</tr>
				<tr>
					<td>Your Last Name:</td>
					<td>
					<input type="text" name="lastname" placeholder="Enter Last name" required="1"/>
					</td>
				</tr>
				
				<tr>
					<td>Your Email Address:</td>
					<td>
					<input type="email" name="email" placeholder="Enter Email Address" required="1"/>
					</td>
				</tr>
				<tr>
					<td>Your Message:</td>
					<td>
					<textarea name="msg"></textarea>
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
					<input type="submit" name="submit" value="Send"/>
					</td>
				</tr>
		</table>
	<form>				
 </div>

		</div>
		<?php include 'inc/sidebar.php'; ?>	
		<?php include 'inc/footer.php'; ?>