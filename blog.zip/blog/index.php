
<?php 
include 'inc/header.php'; 
?>		
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<?php
			$per_page=3;
			if(isset($_GET['page'])){
				$page=$_GET['page'];
			}
			else{
				$page=1;
			}
			$start_from=($page-1)*$per_page;

			?>
		<?php 
			$sql="SELECT * from post limit $start_from,$per_page";
			$result=$database->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){?>
			<div class="samepost clear">
			
		
				<h2><a href='post.php?id=<?php echo $row['id']; ?>'> <?php echo $row['title']; ?> </a></h2>
				<h4><?php echo $format->formatDate($row['date']); ?>, By <a href="#"><?php echo $row['author']; ?></a></h4>
				 <a href="#"><img src="images/<?php echo $row['img']; ?>" alt="post image"/></a>
				
				<?php echo $format->read($row['content'],200); ?>
				
				<div class="readmore clear">
					<a href='post.php?id=<?php echo $row['id']; ?>'>Read More</a>
								</div>
									
			</div>
			
			<?php }?>
			<!--pagination--><?php
			$sql="SELECT * from post";
			$result=$database->select($sql);
			$rows=mysqli_num_rows($result);
			$pages=ceil($rows/$per_page);
			echo "<span class='pagination'><a href='index.php?page=1'>Start</a>";
			for($i=2;$i<$pages;$i++){
				echo "<a href='index.php?page=$i'>.$i.</a>";
			}
			echo "<a href='index.php?page=$pages'>End</a>";
			echo "</span>";?><?php
		}else{
			header('Location:404.php');
		}
		?>	
		</div>
		
		<?php include 'inc/sidebar.php'; ?>	
		<?php include 'inc/footer.php'; ?>	
